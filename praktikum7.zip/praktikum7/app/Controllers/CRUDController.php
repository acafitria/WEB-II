<?php

namespace App\Controllers;

use App\Controllers\BaseController;
//Mengunakan model yang telah dibuat tadi
use App\Models\BukuModel;

class CRUDController extends BaseController
{
    public function index()
    {

        //Mengambil data dari model
        $model = new BukuModel();
        $semuaData = $model->findAll(); //Menjalankan select * from
        //Tempat menjalankan logika untunk fungsi CRUD
        return view("index",[
            "data" => $semuaData
        ]);

    }

    public function tambah() 
    {
        return view("create");
    }

    public function simpan()
    {
        $model = new BukuModel();
        //mengambil value yang kita inpt dari froms
        $judul = request()->getPost("judul");
        $penulis = request()->getPost("penulis");
        $penerbit = request()->getPost("penerbit");
        $tahun_terbit = request()->getPost("tahun_terbit");

        //Fungsi menambahkan data
        $model -> insert([
            "judul" => $judul,
            "penulis" => $penulis,
            "penerbit" => $penerbit,
            "tahun_terbit" => $tahun_terbit
        ]);
        //Mederect user setelah menambah data
        return redirect() ->to(base_url('/'));
    }

    public function edit($id)
    {
        $model = new BukuModel();
        $data = $model-> find($id);

        return view('edit', [
            "data" => $data
        ]);
    }


    
    public function update($id)
    {
        $model = new BukuModel();
        $judul = request()->getPost("judul");
        $penulis = request()->getPost("penulis");
        $penerbit = request()->getPost("penerbit");
        $tahun_terbit = request()->getPost("tahun_terbit");

        $model -> update($id, [
            "judul" => $judul,
            "penulis" => $penulis,
            "penerbit" => $penerbit,
            "tahun_terbit" => $tahun_terbit
        ]);
        //Mederect user setelah menambah data
        return redirect() ->to(base_url('/'));

        return view('edit', [
            "data" => $data
        ]);

    //Mederect user setelah menambah data
        return redirect() ->to(base_url('/'));
    }

    public function hapus($id)
    {
        $model = new BukuModel();
        $model -> delete($id);
        return redirect() ->to(base_url('/'));
    }
    
}
